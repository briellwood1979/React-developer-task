import React from "react";

/** @type {React.FC} */
export const Home = ({}) => {
  return <div>Hello world</div>;
};
